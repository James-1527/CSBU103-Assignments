const UserModel = require('./user.local')
module.exports = {
    UserModel
}