
const UserController = require('./user')

module.exports = {
    UserController
}